package controller.user_login;

public interface UserLoginService {
    public String LoginUser(String email,String password);
}
