package controller.user_register;

public interface RegisterUserService {

    public boolean userReister(String password,String cPassword,String email, String name);

}
