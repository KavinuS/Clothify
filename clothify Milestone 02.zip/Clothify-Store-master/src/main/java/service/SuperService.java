package service;

public interface SuperService {
}
