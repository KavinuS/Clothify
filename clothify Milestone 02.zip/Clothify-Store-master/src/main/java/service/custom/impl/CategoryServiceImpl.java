package service.custom.impl;

import dto.Suppler;
import javafx.collections.ObservableList;
import service.custom.CategorySevice;

public class CategoryServiceImpl implements CategorySevice {
    @Override
    public ObservableList<String> getAllId() {
        return null;
    }

}
