package repository;

public interface SuperDao {
}
