public class     Starter {
    public static void main(String[] args) {
        Main.main(args);
    }
}
